// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/GameMode.h"
#include "MyCppGameMode.generated.h"

/**
 * 
 */
UCLASS()
class MYCPP_API AMyCppGameMode : public AGameMode
{
	GENERATED_BODY()
	
	
	
	
};
