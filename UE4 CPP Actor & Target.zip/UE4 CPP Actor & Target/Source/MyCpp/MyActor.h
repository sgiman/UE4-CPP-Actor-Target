/*******************************************************************************
                                 MyActor.h
********************************************************************************/
// Fill out your copyright notice in the Description page of Project Settings.
#pragma once


#include "GameFramework/Actor.h"
#include "MyActor.generated.h"

UCLASS()

class MYCPP_API AMyActor : public AActor
{
	GENERATED_BODY()

public:
	
	bool MyBool;
	int8 MyInt8;

	// Sets default values for this actor's properties
	AMyActor();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	// Called every frame
	// virtual void Tick(float DeltaSeconds) override;
	
	//------------------------------------------------------------------------------------
	// SET private BOOLEAN to "TRUE"
	void MyMethod();

	bool MyFunction();
};



//----------------------------------------------------------------------------------------
/*
// TYPE NAME ARE PREFIXED:
// Template clasees are prefixed by T
// Clasees that inherit from UObject are prefixed by U
// Clasees that inherit from AActor are prefixed by A
// Clasees that inherit from SWidget are prefixed by S
// Clasees that are abstract interface are prefixed by I
// Most others classes asre prefixed by F, thogh some subsystem use other letters
// boolean - "b"


//
// Whole positive integers
uint8 MyUint8;    // 0 to 155
uint16 MyUint16;  // 0 to 65 555
uint32 MyUint32;  // 0 to 4 294 967 295
uint64 MyUint64;  // 0 to 18 446 744 073 709 551 615

// Whole positive or negative integers
int8 MyInt8;
int16 MyInt16;
int32 MyInt32;
int64 MyInt64;

// Boolean
bool MyBool;

//Real numbers
float MyFloat;
double MyDouble;

// CHARS
TCHAR MyTCHAR;  // char
PTRINT MyPTRINT // pointer for char

// Sets default values for this actor's properties
AMyActor();

*/

